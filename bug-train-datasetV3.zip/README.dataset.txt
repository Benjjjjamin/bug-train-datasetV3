# Oriental-fruit-fly > bug-train-datasetV3
https://universe.roboflow.com/object-detection/oriental-fruit-fly

Provided by a Roboflow user
License: CC BY 4.0

